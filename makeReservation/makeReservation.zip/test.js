let handler = require('./index');
let options = {
    "name": "Frank",
    "email": "frank@gmail.com",
    "phone": "8908876545",
    "size": "4",
    "date": "2-2-201",
    "time": "5pm"
}
let e = {
    options: options
}
handler.handler(e)
let handler = require('./index');
let options = {
    "name": "Dennis",
    "email": "denn@gmail.com",
    "rating": 2,
    "comment": "Exceptional"
}
handler.handler(options);
const h = require('./index.js')
h.handler()